package app;

import java.util.PriorityQueue;

public class CreatePriorityQueueExample {
	public static void main(String[] args) {
		/*
		 * Queue is an abstract data structure, somewhat similar to Stacks.
		 * Unlike stacks, a queue is open at both its ends.
		 * One end is always used to insert data (enqueue) and the other is used to remove data (dequeue)
		 */
		
		// Create a Priority Queue
		PriorityQueue<Integer> numbers = new PriorityQueue<>();
		
		// Add items to a Priority Queue (ENQUEUE)
		numbers.add(750);
		numbers.add(500);
		numbers.add(900);
		numbers.add(100);
		
		// Remove items from the Priority Queue (DEQUEUE)
		while (!numbers.isEmpty()) {
			System.out.println(numbers.remove());
		}
	}
}
