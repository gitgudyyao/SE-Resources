package app;

import java.util.Arrays;
import java.util.Collections;
import java.util.PriorityQueue;

public class ReversedPriorityQueue {

	public static void main(String[] args) {
		PriorityQueue<Integer> queue = new PriorityQueue<>(2, Collections.reverseOrder());
		
		queue.addAll(Arrays.asList(3, 4, 1, 2, 6, 8));
		
		System.out.println(queue);
	}

}
