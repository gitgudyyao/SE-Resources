package app;

import java.util.LinkedList;

public class TestSpeed {
	public static void main(String[] args) {
	
		LinkedList<Integer> list = new LinkedList<Integer>();
		for (int i = 0; i < 50000; i++)
			list.add(i);
		
		// Using index
		long startTime = System.currentTimeMillis();
		int x;
		for (int i = 0; i < list.size(); i++)
			x = list.get(i);
		long endTime = System.currentTimeMillis();
		
		System.out.println("Using index:");
		System.out.println(endTime - startTime);
		System.out.println();
		
		// for-each
		startTime = System.currentTimeMillis();
		for (int i: list)
			x = i;
		endTime = System.currentTimeMillis();
		
		System.out.println("for-each:");
		System.out.println(endTime - startTime);
		
	}
}
