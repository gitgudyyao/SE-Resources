package app;

import java.util.Arrays;
import java.util.PriorityQueue;

public class SetOpsPriorityQueue {
	public static void main(String[] args) {
		
		PriorityQueue<String> queue1 = new PriorityQueue<>();
		PriorityQueue<String> queue2 = new PriorityQueue<>();
		
		queue1.addAll(Arrays.asList("George", "Jim", "John", "Blake", "Kevin", "Michael"));
		queue2.addAll(Arrays.asList("George", "Katie", "Kevin", "Michelle", "Ryan"));
		
		// union
		/*
		System.out.println(queue1);
		queue1.addAll(queue2);
		System.out.println(queue1);
		System.out.println();
		
		while (!queue1.isEmpty()) {
			System.out.println(queue1.remove());
		}
		*/
		
		// difference
		/*
		System.out.println(queue1);
		queue1.removeAll(queue2);
		System.out.println(queue1);
		System.out.println();
		*/
		
		// intersection
		
		System.out.println(queue1);
		queue1.retainAll(queue2);
		System.out.println(queue1);
		System.out.println();
		
	}
}
