package app;

import java.util.LinkedList;

public class TestLinkedList {

	public static void main(String[] args) {
		/*
		LinkedList<String> list1 = new LinkedList<String>();
		LinkedList<String> list2 = new LinkedList<String>();
		
		list1.add(0, "red");
		list1.add(1, "yellow");
		list1.add(2, "green");
		
		list2.add(0, "red");
		list2.add(1, "yellow");
		list2.add(2, "blue");

		list1.addAll(list2);
		System.out.println(list1);
		list1.removeAll(list2);
		System.out.println(list1);
		*/
		
		/*
		list1.add("purple");
		System.out.println(list1);
		list1.remove("purple");
		System.out.println(list1);
		*/
	
		/*
		list1.retainAll(list2);
		System.out.println(list1);
		
		list1.clear();
		System.out.println(list1);
		*/
		
		LinkedList<Object> list1 = new LinkedList<Object>();
		LinkedList<String> list2 = new LinkedList<String>();
		
		list1.add(0, "red");
		list1.add(1, "yellow");
		list1.add(2, "green");
		
		list2.add(0, "red");
		list2.add(1, "yellow");
		list2.add(2, "blue");
		
		list1.add(list2);
		System.out.println(list1);
		list1.remove(list2);
		System.out.println(list1);
		
	}

}
