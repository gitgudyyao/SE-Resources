package practicalLab;

public class practicalExercise {

	public static void main(String[] args) {

		//declare and create integer BST (intTree)
		BST<Integer> tree = new BST<>();

		//declare and create random generator (java.util.Random)

		/**
		loop i from 1 to 20
		    generate a random number in the range of -100 and 100
		    invoke insert() of the integer BST
		 */
		for (int i = 0; i < 20; i++) {
			int num = (int)(Math.random() * 200 - 100);
			System.out.println(num);
			tree.insert(num);
		}

		//invoke inorder() of the integer BST (to check the elements)
		System.out.println("in-order: ");
		tree.inorder();
		System.out.println("");

		// for Question 1
		//invoke getNumberOfLeaves() of the integer BST
		int leaves = tree.getNumberOfLeaves();
		System.out.println("Number of leaves: " + leaves);
		System.out.println("");

		// for Question 3
		// solution 1: use a for-each loop to do traversal
		System.out.println("sum: " + findSum_(tree));

		// solution 2: create recursive method
		System.out.println("sum: " + findSum(tree));

	}

	// solution 1: use a for-each loop to do traversal
	public static int findSum_(BST<Integer> tree) {
		int sum = 0;
		
		for (int e: tree) {
			sum += e;
		}
		
		return sum;
	}
	
	// solution 2: create recursive method
	public static int findSum(BST<Integer> tree) {
		return findSum(tree.root);
	}
	
	public static int findSum(BST.TreeNode<Integer> node) {
		int sum = 0;
		
		if (node != null) {
			sum = node.element + findSum(node.left) + findSum(node.right);
		}
		
		return sum;
	}
}
