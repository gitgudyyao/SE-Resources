package app;

import java.util.Stack;

public class Case_Study_1 {

}

class Container {
	int id;
	String decscription;
	
	public Container(int id, String description) {
		this.id = id;
		this.decscription = description;
	}
}

class ContainerRegion {
	Stack<Container> region[][];
	
	public ContainerRegion() {
		for (int r = 0; r < 10; r++) {
			for (int c = 0; c < 10; c++) {
				region[r][c] = new Stack<Container>();
			}
		}
	}
	
	public Container unload(int id, int r, int c) {
		Container temp = region[r][c].pop();
		while(temp != null) {
			if (id == temp.id)
				break;
			region[0][0].push(temp);
			temp = region[r][c].pop();
		}
		Container found = null;
		if (temp != null && id == temp.id)
			found = temp;
		
		temp = region[0][0].pop();
		while(temp != null) {
			region[r][c].push(temp);
			temp = region[0][0].pop();
		}
		
		return found;
	}
}