package dsaa.app;

public class A {
	public A(int x) {}
	// public A() {}
}

class B extends A {
	public B() {
		super(0);// super(...);
	}
}