package dsaa.app;

public class Test2 {
	public static void main(String[] args) {// static
		System.out.println("What's wrong with this program?");// ;
	}
}
