package dsaa.app;

public class Test1 {
	public static void main(String[] args) {// String[]
		System.out.println("What's wrong with this program?");
	}
}