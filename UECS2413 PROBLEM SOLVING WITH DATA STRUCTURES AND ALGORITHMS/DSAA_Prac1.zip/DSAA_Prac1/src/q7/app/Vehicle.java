package q7.app;

public class Vehicle {}
