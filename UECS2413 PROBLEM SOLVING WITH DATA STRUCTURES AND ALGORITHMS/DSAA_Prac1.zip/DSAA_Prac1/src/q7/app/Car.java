package q7.app;

public class Car extends LandVehicle {
	@Override
	public double getWeight() {
		return 0.0;
	}

	@Override
	public int getSpeed() {
		return 0;
	}
}
