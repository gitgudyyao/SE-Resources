package app;

public interface MyList<E> extends java.lang.Iterable {
	
	public void add(E e);
	public void add(int index, E e);
	public void clear();
	public boolean contains(E e);
	public E get(int index);
	public int indexOf(E e);
	public boolean isEmpty();
	public int lastIndexOf(E e);
	public boolean remove(E e);
	public int size();
	public E remove(int index);
	public E set(int index, E e);
	
	/** Adds the elements in otherList to this list.
	* Returns true if this list changed as a result of the call */
	public boolean addAll(MyList<E> otherList);
	
	/** Removes all the elements in otherList from this list.
	* Returns true if this list changed as a result of the call */
	public boolean removeAll(MyList<E> otherList);
	
	/** Retains the elements in this list that are also in otherList.
	* Returns true if this list changed as a result of the call */
	public boolean retainAll(MyList<E> otherList);
	
}
