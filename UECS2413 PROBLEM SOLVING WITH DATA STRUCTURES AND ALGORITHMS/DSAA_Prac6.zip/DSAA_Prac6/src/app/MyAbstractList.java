package app;

public abstract class MyAbstractList<E> implements MyList<E> {

	protected int size = 0;
	
	protected MyAbstractList() {
		
	}
	
	protected MyAbstractList(E[] objects) {
		for (int i = 0; i < objects.length; i++)
			add(objects[i]);
	}
	
	@Override
	public void add(E e) {
		add(size, e);
	}
	
	@Override
	public boolean isEmpty() {
		return size == 0;
	}
	
	@Override
	public int size() {
		return size;
	}
	
	@Override
	public boolean remove(E e) {
		if (indexOf(e) >= 0) {
			remove(indexOf(e));
			return true;
		}
		else
			return false;
	}
	
	public boolean addAll(MyList<E> otherList) {
		int size = otherList.size();
		
		if (size != 0) {
			for (int i = 0; i < size; i++) {
				add(otherList.get(i));
			}
			return true;
		}
		
		return false;
	}
	
	public boolean removeAll(MyList<E> otherList) {
		/*
		int size = otherList.size();
		
		if (size != 0) {
			for (int i = 0; i < size; i++) {
				remove(otherList.get(i));
			}
			return true;
		}
		
		return false;
		*/
		
		int iniSize = size();
		
		for (int i = 0; i < otherList.size(); i++) {
			remove(otherList.get(i));
		}
		
		return iniSize != size();
	}
	
	public boolean retainAll(MyList<E> otherList) {
		int size = otherList.size();
		
		if (size != 0) {
			E e;
			
			for (int i = 0; i < size; i++) {
				e = otherList.get(i);
				if (!otherList.contains(e))
					remove(e);
			}
			
			return true;
		}
		
		return false;
	}
	
}
