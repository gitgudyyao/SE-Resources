package app;

public class ProgrammingExerciseP8 {

	public static void main(String[] args) {
		// Vertex array for graph
		String[] vertices = {"Seattle", "San Francisco", "Los Angeles",
				"Denver", "Kansas City", "Chicago", "Boston", "New York",
				"Atlanta", "Miami", "Dallas", "Houston"};

		// Edge array for graph
		int[][] edges = {
				{0, 1}, {0, 3}, {0, 5},
				{1, 0}, {1, 2}, {1, 3},
				{2, 1}, {2, 3}, {2, 4}, {2, 10},
				{3, 0}, {3, 1}, {3, 2}, {3, 4}, {3, 5},
				{4, 2}, {4, 3}, {4, 5}, {4, 7}, {4, 8}, {4, 10},
				{5, 0}, {5, 3}, {5, 4}, {5, 6}, {5, 7},
				{6, 5}, {6, 7},
				{7, 4}, {7, 5}, {7, 6}, {7, 8},
				{8, 4}, {8, 7}, {8, 9}, {8, 10}, {8, 11},
				{9, 8}, {9, 11},
				{10, 2}, {10, 4}, {10, 8}, {10, 11},
				{11, 8}, {11, 9}, {11, 10}
		};

		// Build a graph with 12 cities and their edges & Print out all the edges of each cities
		Graph<String> graph1 = new UnweightedGraph<>(vertices, edges);
		System.out.println("The number of vertices in graph: " 
				+ graph1.getSize());
		System.out.println("The vertex with index 1 is " 
				+ graph1.getVertex(1));
		System.out.println("The index for Miami is " + 
				graph1.getIndex("Miami"));
		System.out.println("The edges for graph:");
		graph1.printEdges();

		System.out.print("\n\n\n");

		// Print DFS for the graph
		Graph<String> graphDfs = new UnweightedGraph<>(vertices, edges);
		AbstractGraph<String>.Tree dfs = 
				graphDfs.dfs(graphDfs.getIndex("Chicago")); 

		java.util.List<Integer> searchOrdersDfs = dfs.getSearchOrder();
		System.out.println(dfs.getNumberOfVerticesFound() +
				" vertices are searched in this DFS order:");
		for (int i = 0; i < searchOrdersDfs.size(); i++)
			System.out.print(graphDfs.getVertex(searchOrdersDfs.get(i)) + " ");
		System.out.println();

		for (int i = 0; i < searchOrdersDfs.size(); i++)
			if (dfs.getParent(i) != -1)
				System.out.println("parent of " + graphDfs.getVertex(i) +
						" is " + graphDfs.getVertex(dfs.getParent(i)));

		System.out.print("\n\n\n");

		// Print BFS for the graph
		Graph<String> graphBfs = new UnweightedGraph<>(vertices, edges);
		AbstractGraph<String>.Tree bfs = 
				graphBfs.bfs(graphBfs.getIndex("Chicago"));

		java.util.List<Integer> searchOrdersBfs = bfs.getSearchOrder();
		System.out.println(bfs.getNumberOfVerticesFound() +
				" vertices are searched in this order:");
		for (int i = 0; i < searchOrdersBfs.size(); i++)
			System.out.println(graphBfs.getVertex(searchOrdersBfs.get(i)));

		for (int i = 0; i < searchOrdersBfs.size(); i++)
			if (bfs.getParent(i) != -1)
				System.out.println("parent of " + graphBfs.getVertex(i) + 
						" is " + graphBfs.getVertex(bfs.getParent(i)));

		System.out.print("\n\n\n");
	}

}
