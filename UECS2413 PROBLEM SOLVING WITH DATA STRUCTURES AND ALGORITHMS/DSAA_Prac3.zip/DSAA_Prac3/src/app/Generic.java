package app;

import java.util.ArrayList;

public class Generic {
	public static void main(String[] args) {
		ArrayList<Integer> nums = new ArrayList<Integer>();
		nums.add(new Integer(2));
		nums.add(new Integer(1));
		nums.add(new Integer(5));
		System.out.println(min(nums));
		
		ArrayList<Student> studs = new ArrayList<Student>();
		studs.add(new Student(1, "CK", 12));
		studs.add(new Student(2, "KX", 20));
		studs.add(new Student(2, "CY", 14));
		studs.add(new Student(2, "TC", 28));
		System.out.println(min(studs).getAge());
	}
	
	public static <E extends Comparable<E>> E min(ArrayList<E> list) {
		E currentMin = list.get(0);
		for(int i = 1; i < list.size(); i++){
			if (currentMin.compareTo(list.get(i)) > 0)
				currentMin = list.get(i);
		}
		return currentMin;
	}
}

class Student implements Comparable<Student> {
	private int indexNo;
	private String name;
	private int age;
	
	public Student(int indexNo, String name, int age) {
		this.indexNo = indexNo;
		this.name = name;
		this.age = age;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public int compareTo(Student st) {
		if (this.age == st.age)
			return 0;
		else if (this.age > st.age)
			return 1;
		else
			return -1;
	}
}